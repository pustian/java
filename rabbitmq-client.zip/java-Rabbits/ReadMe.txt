java-rabbit-0 生产消费者 在同一个Main中
java-rabbit-1 生产消费者 在两个Main中 QueueingConsumer.
java-rabbit-2 1个生产 多个消费者 在两个Main中